-- Ziorpure products table for Supabase
-- 1) Replace YOUR_ADMIN_USER_UUID below with your admin user's UUID from Supabase Authentication > Users.
-- 2) Run this whole file in Supabase SQL Editor.
create table if not exists public.products (
  id text primary key,
  name text not null,
  price numeric(10,2) default null check (price is null or price >= 0),
  updated_at timestamptz not null default now()
);

alter table public.products enable row level security;

grant select on public.products to anon, authenticated;
grant update on public.products to authenticated;

drop policy if exists "Public can read products" on public.products;
create policy "Public can read products" on public.products
for select to anon, authenticated using (true);

drop policy if exists "Only Ziorpure admin can update prices" on public.products;
create policy "Only Ziorpure admin can update prices" on public.products
for update to authenticated
using (auth.uid() = 'YOUR_ADMIN_USER_UUID'::uuid)
with check (auth.uid() = 'YOUR_ADMIN_USER_UUID'::uuid);

insert into public.products (id, name, price) values
('keratin-shampoo','Keratin Pearl Shampoo',null),
('hair-serum','Nourishing Hair Serum',null),
('hair-mask','Hair Mask',null),
('kojic-soap','Kojic Soap',null),
('herbal-soap','Herbal Soap',null)
on conflict (id) do update set name=excluded.name;
