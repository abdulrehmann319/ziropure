# Ziorpure Website

A responsive, animated one-page website built with plain HTML, CSS and JavaScript. Includes five product cards and WhatsApp order buttons. No build tools or paid hosting required.

## Before publishing
1. Open `index.html` and replace the demo WhatsApp number `923001234567` with your own number, including country code but without `+` or spaces.
2. Update product prices and wording if needed.
3. The five products are Keratin Pearl Shampoo, Nourishing Hair Serum, Hair Mask, Kojic Soap and Herbal Soap.

## Publish free with GitHub Pages
1. Create a public repository on GitHub (for example, `ziorpure-website`).
2. Upload `index.html`, `README.md`, and the complete `assets` folder.
3. Go to **Settings → Pages**.
4. Choose **Deploy from a branch**, branch **main**, folder **/(root)**, then press **Save**.
5. Wait a minute or two; GitHub Pages will show the live URL on the same page.
